import React from 'react';
import { X, Github, MessageSquareText } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

const GoogleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

interface LoginPromptModalProps {
  open: boolean;
  onClose: () => void;
}

const LoginPromptModal: React.FC<LoginPromptModalProps> = ({ open, onClose }) => {
  const { loginWithGithub, loginWithGoogle } = useAuth();

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-sm rounded-2xl border border-cyber-700 bg-cyber-900 shadow-2xl animate-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute -top-3 -right-3 z-10 w-8 h-8 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center shadow-lg transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="p-6 sm:p-8 text-center space-y-5">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-cyber-500 to-purple-500 flex items-center justify-center">
            <MessageSquareText className="w-7 h-7 text-white" />
          </div>

          <div>
            <h2 className="text-xl font-bold text-white">Keep the conversation going</h2>
            <p className="text-sm text-slate-400 mt-2">
              You've reached 15 messages. Sign in to save your chat history and continue anytime.
            </p>
          </div>

          <div className="space-y-2">
            <button
              onClick={loginWithGithub}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#24292e] hover:bg-[#1a1e22] text-white text-sm font-medium transition-colors"
            >
              <Github className="w-4 h-4" />
              Continue with GitHub
            </button>
            <button
              onClick={loginWithGoogle}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 text-sm font-medium transition-colors"
            >
              <GoogleIcon className="w-4 h-4" />
              Continue with Google
            </button>
          </div>

          <button onClick={onClose} className="text-xs text-slate-500 hover:text-slate-300 transition-colors">
            Maybe later
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPromptModal;
